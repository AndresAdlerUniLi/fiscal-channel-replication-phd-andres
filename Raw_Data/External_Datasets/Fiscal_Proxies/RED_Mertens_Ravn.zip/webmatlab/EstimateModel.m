% Understanding The Aggregate Effects of Anticipated and Unanticipated US
% Tax Policy Shocks
%
% Karel Mertens and Morten Ravn
%
% This program estimates the benchmark model and Replicates Figures 3 and 4.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all; close all;
addpath('auxfiles')

 % Load empirical VAR specification and results
load('matresults\RES');
load('matresults\VAR'); 
load('matresults\SIMSHOCKS');
SHOCKS = SIMSHOCKS;

SHOCKS.Tam=sum(SHOCKS.Tam,2);
T=240;
N=100;
TTA = zeros(T*N,7,7);
for j=7;
     for jj = j:-1:1;
     TTA(1+j-jj:end,jj,j) =SHOCKS.Tam(1:end-(j-jj),1); 
     end
 end
SHOCKS.Ta=sum(TTA,3);

% MODEL PARAMETERS
    % Utility Parameters
PARS.betastar = 1.03^-0.25; PARS.sigma = 3.7621; PARS.kappa = 0.9759; PARS.mu = 0.8804;
    % Technology Parameters
PARS.alfa = 0.36; PARS.delta = 0.025; PARS.phik =8.4875; PARS.phiv = 7.7948; PARS.psik = 0.6191;
PARS.gammaz = 1.005;
    % Policy Parameters 
PARS.tauk = 0.42; PARS.taun = 0.26; PARS.deltat = 0.05; PARS.b = VAR.K;
PARS.rhok1 = 1.7073; PARS.rhok2 = -0.7287; PARS.rhon1= 1.4831; PARS.rhon2 = -0.4836;

PARS.lamk1 = (PARS.rhok1 + sqrt(PARS.rhok1^2+4*PARS.rhok2))/2;
PARS.lamk2 = (PARS.rhok1 - sqrt(PARS.rhok1^2+4*PARS.rhok2))/2;
PARS.lamn1 = (PARS.rhon1 + sqrt(PARS.rhon1^2+4*PARS.rhon2))/2;
PARS.lamn2 = (PARS.rhon1 - sqrt(PARS.rhon1^2+4*PARS.rhon2))/2;

% % ESTIMATION INPUTS
Teta2     = [1/PARS.sigma PARS.kappa (PARS.mu/(1-PARS.mu))^0.5 PARS.phik PARS.phiv PARS.psik... 
             (PARS.lamk1/(1-PARS.lamk1))^0.5 (PARS.lamk2/(1-PARS.lamk2))^0.5 (PARS.lamn1/(1-PARS.lamn1))^0.5 (PARS.lamn2/(1-PARS.lamn2))^0.5];
         
EST.select =[1            1           1                        1         1         1     ...
             1            1           1                        1   ];
EST.iSig      = inv(diag([RES.IRsupvar(:);RES.IRantvar(:)]));     % Weigthing matrix
EST.Lambdahat = [RES.IRsup(:);RES.IRant(:)];                      % Empirical IRs
EST.nsim      = 100;                                              % Number of Artifical Samples
EST.Sigma     = RES.IRcov;

x0            = Teta2(EST.select==1);
 
                              
[xhat,fval,exitflag] = fminsearch(@lossfunction,x0,optimset('GradObj','off','Hessian','off'...
                                   ,'MaxIter',10000,'LargeScale','off',...
                                   'MaxFunEvals',1.e+10,'TolFun',1e-6,'TolX',1e-6,...
                                   'Display','iter','FunValCheck','on'),PARS,EST,VAR,SHOCKS);
                               
SE = doStandardErrors(xhat,PARS,EST,VAR,SHOCKS);

j=1;
if EST.select(1)==1;  Teta2hat(j) = 1/xhat(j); j=j+1; end
if EST.select(2)==1;  Teta2hat(j) = abs(xhat(j)); j=j+1; end
if EST.select(3)==1;  Teta2hat(j) = xhat(j)^2/(1+xhat(j)^2); j=j+1; end
if EST.select(4)==1;  Teta2hat(j) = abs(xhat(j)); j=j+1; end
if EST.select(5)==1;  Teta2hat(j) = abs(xhat(j)); j=j+1; end
if EST.select(6)==1;  Teta2hat(j) = abs(xhat(j)); j=j+1; end
if EST.select(7)==1;  Teta2hat(j) = min(xhat(j)^2/(1+xhat(j)^2),0.999); PARS.lamk1 = Teta2hat(j); j=j+1; end
if EST.select(8)==1;  Teta2hat(j) = min(xhat(j)^2/(1+xhat(j)^2),0.999); PARS.lamk2 = Teta2hat(j); j=j+1; end
if EST.select(9)==1;  Teta2hat(j) = min(xhat(j)^2/(1+xhat(j)^2),0.999); PARS.lamn1 = Teta2hat(j); j=j+1; end
if EST.select(10)==1; Teta2hat(j) = min(xhat(j)^2/(1+xhat(j)^2),0.999); PARS.lamn2 = Teta2hat(j);end


doFigure3(xhat,PARS,EST,VAR,RES,SHOCKS,1)
doFigure4(xhat,PARS,EST,VAR,RES,SHOCKS,1)






