% Understanding The Aggregate Effects of Anticipated and Unanticipated US
% Tax Policy Shocks
%
% Karel Mertens and Morten Ravn
%
% This program replicates Figure 1 in the paper.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all; close all;
addpath('auxfiles')

% 1. Read the data
data    =  xlsread('MR_DATA_RED');
OUTPUT  =  data(:,2);
ND_CONS =  data(:,3);
D_CONS  =  data(:,4);
INV     =  data(:,5);
HOURS   =  data(:,6);

% 2. Specify the VAR
VAR.P      = 1;         % number of lags of the endogenous variables
VAR.R      = 12;        % number of lags of the exogenous tax shocks
VAR.K      = 6;         % number of tax leads
VAR.irhor  = 24;        % length of impulse response

VAR.X  = [OUTPUT ND_CONS INV HOURS D_CONS];
VAR.Tu  =  data(:,7)/100;
VAR.Ta  =  data(:,8:8+VAR.K)/100;
[VAR.T,VAR.nx]=size(VAR.X);

% 3. Do VAR
VAR.boot = 1;      % 1 if you want bootstrapped confidence intervals
VAR.nboot = 10000; % number of bootstrap replications
VAR.clevel = 68;   % confidence level


RES = doVAR(VAR);
doFigure1(VAR,RES);
close all

