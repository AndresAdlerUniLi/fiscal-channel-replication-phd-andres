 % Plot Results

function [h1,h2,h3,h4,h5] = doFigure1(VAR,RES)
close all

vysup = [zeros(VAR.K+1,1); RES.IRsup(1:VAR.irhor+1,1)];
veysup =[[zeros(VAR.K+1,1); RES.IRsupcih(:,1)]...
    [zeros(VAR.K+1,1); RES.IRsupcil(:,1)]];

vyant=[0;RES.IRant(1:1+VAR.K+VAR.irhor,1)];
veyant =[[0;RES.IRantcih(:,1)] [0;RES.IRantcil(:,1)]];

LOWy = min(min([vysup veysup vyant veyant]));
UPy  = max(max([vysup veysup vyant veyant]));

vcsup=[zeros(VAR.K+1,1); RES.IRsup(1:VAR.irhor+1,2)];
vecsup =[[zeros(VAR.K+1,1); RES.IRsupcih(:,2)]...
    [zeros(VAR.K+1,1); RES.IRsupcil(:,2)]];
vcant=[0;RES.IRant(1:1+VAR.K+VAR.irhor,2)];
vecant =[[0;RES.IRantcih(:,2)] [0;RES.IRantcil(:,2)]];

LOWc = min(min([vcsup vecsup vcant vecant]));
UPc  = max(max([vcsup vecsup vcant vecant]));

visup=[zeros(VAR.K+1,1); RES.IRsup(1:VAR.irhor+1,3)];
veisup =[[zeros(VAR.K+1,1); RES.IRsupcih(:,3)]...
    [zeros(VAR.K+1,1); RES.IRsupcil(:,3)]];
viant=[0;RES.IRant(1:1+VAR.K+VAR.irhor,3)];
veiant =[[0;RES.IRantcih(:,3)] [0;RES.IRantcil(:,3)]];

LOWi = min(min([visup veisup viant veiant]));
UPi  = max(max([visup veisup viant veiant]));

vhsup=[zeros(VAR.K+1,1); RES.IRsup(1:VAR.irhor+1,4)];
vehsup =[[zeros(VAR.K+1,1); RES.IRsupcih(:,4)]...
    [zeros(VAR.K+1,1); RES.IRsupcil(:,4)]];
vhant=[0;RES.IRant(1:1+VAR.K+VAR.irhor,4)];
vehant =[[0;RES.IRantcih(:,4)] [0;RES.IRantcil(:,4)]];

LOWh = min(min([vhsup vehsup vhant vehant]));
UPh  = max(max([vhsup vehsup vhant vehant]));

vdsup = [zeros(VAR.K+1,1); RES.IRsup(1:VAR.irhor+1,5)];
vedsup =[[zeros(VAR.K+1,1); RES.IRsupcih(:,5)]...
    [zeros(VAR.K+1,1); RES.IRsupcil(:,5)]];

vdant=[0;RES.IRant(1:1+VAR.K+VAR.irhor,5)];
vedant =[[0;RES.IRantcih(:,5)] [0;RES.IRantcil(:,5)]];

LOWd = min(min([vdsup vedsup vdant vedant]));
UPd  = max(max([vdsup vedsup vdant vedant]));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
h1=figure;
subplot(2,2,1)
box on;
S=-VAR.K-1:VAR.irhor;
for i=VAR.K+2:length(S)-1
X=[S(i) S(i) S(i+1) S(i+1)];
Y=[veysup(i,1) veysup(i,2) veysup(i+1,2) veysup(i+1,1)];
if i==1
gg=patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
else patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
end
end
hold on
plot(-VAR.K-1:VAR.irhor,vysup(:,1),'ko-','MarkerSize',3)
hold on
plot(-VAR.K-1:VAR.irhor,zeros(VAR.K+1+VAR.irhor+1,1),'k')
hold off
set(gca,'XTick',[-5 0 5 10 15 20],'FontSize',5)
axis([-0.1 VAR.irhor+0.1 LOWy UPy ])
xlabel('quarters','FontSize',8)
ylabel('percent','FontSize',8)
title('Output','FontWeight','bold','FontSize',8)

subplot(2,2,2)
box on;
S=-1-VAR.K:VAR.irhor;
for i=2:length(S)-1
X=[S(i) S(i) S(i+1) S(i+1)];
Y=[veyant(i,1) veyant(i,2) veyant(i+1,2) veyant(i+1,1)];
if i==1
gg=patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
else patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
end
end
hold on
plot(-1-VAR.K:VAR.irhor,vyant(:,1),'ko-','MarkerSize',3)
hold on
plot(-1-VAR.K:VAR.irhor,zeros(VAR.K+1+VAR.irhor+1,1),'k')
hold off
set(gca,'XTick',[-5 0 5 10 15 20],'FontSize',5)
axis([-0.1-VAR.K VAR.irhor+0.1 LOWy UPy ])
xlabel('quarters','FontSize',8)
ylabel('percent','FontSize',8)
title('Output','FontWeight','bold','FontSize',8)
saveas(gcf,'epsgraphs/Fig1_OUT','eps');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
h2=figure;
subplot(2,2,1)
box on;
S=-VAR.K-1:VAR.irhor;
for i=VAR.K+2:length(S)-1
X=[S(i) S(i) S(i+1) S(i+1)];
Y=[vecsup(i,1) vecsup(i,2) vecsup(i+1,2) vecsup(i+1,1)];
if i==1
gg=patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
else patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
end
end
hold on
plot(-VAR.K-1:VAR.irhor,vcsup(:,1),'ko-','MarkerSize',3)
hold on
plot(-VAR.K-1:VAR.irhor,zeros(VAR.K+1+VAR.irhor+1,1),'k')
hold off
set(gca,'XTick',[-5 0 5 10 15 20],'FontSize',5)
axis([-0.1 VAR.irhor+0.1 LOWc UPc ])
xlabel('quarters','FontSize',8)
ylabel('percent','FontSize',8)
title('Nondurables Consumption','FontWeight','bold','FontSize',8)

subplot(2,2,2)
box on;
S=-VAR.K-1:VAR.irhor;
for i=2:length(S)-1
X=[S(i) S(i) S(i+1) S(i+1)];
Y=[vecant(i,1) vecant(i,2) vecant(i+1,2) vecant(i+1,1)];
if i==1
gg=patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
else patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
end
end
hold on
plot(-VAR.K-1:VAR.irhor,vcant(:,1),'ko-','MarkerSize',3)
hold on 
plot(-VAR.K-1:VAR.irhor,zeros(VAR.K+1+VAR.irhor+1,1),'k')
hold off
set(gca,'XTick',[-5 0 5 10 15 20],'FontSize',5)
axis([-0.1-VAR.K VAR.irhor+0.1 LOWc UPc ])
xlabel('quarters','FontSize',8)
ylabel('percent','FontSize',8)
title('Nondurables Consumption','FontWeight','bold','FontSize',8)
saveas(gcf,'epsgraphs/Fig1_CON','eps');
%%%%%%%%%%%%%%%%%%
h3 = figure;
subplot(2,2,1)
box on;
S=-VAR.K-1:VAR.irhor;
for i=VAR.K+2:length(S)-1
X=[S(i) S(i) S(i+1) S(i+1)];
Y=[veisup(i,1) veisup(i,2) veisup(i+1,2) veisup(i+1,1)];
if i==1
gg=patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
else patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
end
end
hold on
plot(-VAR.K-1:VAR.irhor,visup(:,1),'ko-','MarkerSize',3)
hold on
plot(-VAR.K-1:VAR.irhor,zeros(VAR.K+1+VAR.irhor+1,1),'k')
hold off
set(gca,'XTick',[-5 0 5 10 15 20],'FontSize',5)
axis([-0.1 VAR.irhor+0.1 LOWi UPi ])
xlabel('quarters','FontSize',8)
ylabel('percent','FontSize',8)
title('Investment','FontWeight','bold','FontSize',8)

subplot(2,2,2)
box on;
S=-VAR.K-1:VAR.irhor;
for i=2:length(S)-1
X=[S(i) S(i) S(i+1) S(i+1)];
Y=[veiant(i,1) veiant(i,2) veiant(i+1,2) veiant(i+1,1)];
if i==1
gg=patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
else patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
end
end
hold on
plot(-VAR.K-1:VAR.irhor,viant(:,1),'ko-','MarkerSize',3)
hold on
plot(-VAR.K-1:VAR.irhor,zeros(VAR.K+1+VAR.irhor+1,1),'k')
hold off
set(gca,'XTick',[-5 0 5 10 15 20],'FontSize',5)
axis([-0.1-VAR.K VAR.irhor+0.1 LOWi UPi ])
xlabel('quarters','FontSize',8)
ylabel('percent','FontSize',8)
title('Investment','FontWeight','bold','FontSize',8)
saveas(gcf,'epsgraphs/Fig1_INV','eps');
%%%%%%%%%%%%%%%%%%%%
h4 =figure;
subplot(2,2,1)
box on;
S=-VAR.K-1:VAR.irhor;
for i=VAR.K+2:length(S)-1
X=[S(i) S(i) S(i+1) S(i+1)];
Y=[vehsup(i,1) vehsup(i,2) vehsup(i+1,2) vehsup(i+1,1)];
if i==1
gg=patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
else patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
end
end
hold on
l1=plot(-VAR.K-1:VAR.irhor,vhsup(:,1),'ko-','MarkerSize',3);
hold on
plot(-VAR.K-1:VAR.irhor,zeros(VAR.K+1+VAR.irhor+1,1),'k')
xlabel('quarters','FontSize',8)
ylabel('percent','FontSize',8)
set(gca,'XTick',[-5 0 5 10 15 20],'FontSize',5)
axis([-0.1 VAR.irhor+0.1 LOWh UPh ])
title('Hours','FontWeight','bold','FontSize',8)
hold off

subplot(2,2,2)
box on;
S=-VAR.K-1:VAR.irhor;
for i=2:length(S)-1
X=[S(i) S(i) S(i+1) S(i+1)];
Y=[vehant(i,1) vehant(i,2) vehant(i+1,2) vehant(i+1,1)];
if i==1
gg=patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
else patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
end
end
hold on
l1=plot(-VAR.K-1:VAR.irhor,vhant(:,1),'ko-','MarkerSize',3);
hold on
plot(-VAR.K-1:VAR.irhor,zeros(VAR.K+1+VAR.irhor+1,1),'k')
hold off
set(gca,'XTick',[-5 0 5 10 15 20],'FontSize',5)
axis([-0.1-VAR.K VAR.irhor+0.1 LOWh UPh ])
xlabel('quarters','FontSize',8)
ylabel('percent','FontSize',8)
title('Hours','FontWeight','bold','FontSize',8)
box on
saveas(gcf,'epsgraphs/Fig1_HOURS','eps');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
h5=figure;

subplot(2,2,1)
box on;
S=-1-VAR.K:VAR.irhor;
for i=VAR.K+2:length(S)-1
X=[S(i) S(i) S(i+1) S(i+1)];
Y=[vedsup(i,1) vedsup(i,2) vedsup(i+1,2) vedsup(i+1,1)];
if i==1
gg=patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
else patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
end
end
hold on
plot(-1-VAR.K:VAR.irhor,vdsup(:,1),'ko-','MarkerSize',3)
hold on
plot(-1-VAR.K:VAR.irhor,zeros(VAR.K+1+VAR.irhor+1,1),'k')
hold off
set(gca,'XTick',[-5 0 5 10 15 20],'FontSize',5)
axis([-0.1 VAR.irhor+0.1 LOWd UPd ])
xlabel('quarters','FontSize',8)
ylabel('percent','FontSize',8)
title('Durables Purchases','FontWeight','bold','FontSize',8)

subplot(2,2,2)
box on;
S=-VAR.K-1:VAR.irhor;
for i=2:length(S)-1
X=[S(i) S(i) S(i+1) S(i+1)];
Y=[vedant(i,1) vedant(i,2) vedant(i+1,2) vedant(i+1,1)];
if i==1
gg=patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
else patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
end
end
hold on
plot(-VAR.K-1:VAR.irhor,vdant(:,1),'ko-','MarkerSize',3)
hold on 
plot(-VAR.K-1:VAR.irhor,zeros(VAR.K+1+VAR.irhor+1,1),'k')
hold off
set(gca,'XTick',[-5 0 5 10 15 20],'FontSize',5)
axis([-0.1-VAR.K VAR.irhor+0.1 LOWd UPd ])
xlabel('quarters','FontSize',8)
ylabel('percent','FontSize',8)
title('Durables Purchases','FontWeight','bold','FontSize',8)
% legend1=legend([l2 l1],'Data','Model','Location','NorthEast');
% set(legend1,'Orientation','horizontal',...
%     'Position',[0.2676 0.005 0.5038 0.0462],'Fontsize',8);

saveas(gcf,'epsgraphs/Fig1_DUR','eps');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
