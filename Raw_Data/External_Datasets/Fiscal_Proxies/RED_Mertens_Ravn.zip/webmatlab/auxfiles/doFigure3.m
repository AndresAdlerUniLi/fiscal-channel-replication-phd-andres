 function h1 = doFigure3(xhat,PARS,EST,VAR,RES,SHOCKS,sav)

figno = 'epsgraphs/Fig3_FH';
 
[OBJ,ERES,SOL]  = lossfunction(xhat,PARS,EST,VAR,SHOCKS,1)
     
h1 =figure;
subplot(2,2,1)
l1=plot(0:VAR.irhor,SOL.irtauNU,'k-o','MarkerSize',3);
hold on
l2=plot(0:VAR.irhor,SOL.irtauKU,'k-s','MarkerSize',3);
hold on
l3=plot(0:VAR.irhor,SOL.irtaxU,'k-d','MarkerSize',3);
hold off
xlabel('quarters','FontSize',8);
ylabel('percent','FontSize',8);
set(gca,'XTick',[ 0 5 10 15 20],'FontSize',5);
axis([-0.1 VAR.irhor+0.1-1 -4.5 0 ]);
title('Taxes','FontWeight','bold','FontSize',8)

legend1=legend([l1 l2 l3],'Labor Income Tax','Capital Income Tax','Total Tax Liabilities/Output','Location','NorthWest');

subplot(2,2,2)
l1=plot(-VAR.K:VAR.irhor,SOL.irtauNA,'k-o','MarkerSize',3);
hold on
l2=plot(-VAR.K:VAR.irhor,SOL.irtauKA,'k-s','MarkerSize',3);
hold on
l3=plot(-VAR.K:VAR.irhor,SOL.irtaxA,'k-d','MarkerSize',3);
hold off
xlabel('quarters','FontSize',8);
ylabel('percent','FontSize',8);
set(gca,'XTick',[-5 0 5 10 15 20],'FontSize',5);
axis([-0.1-VAR.K VAR.irhor+0.1-1 -4.5 0 ]);
title('Taxes','FontWeight','bold','FontSize',8)

legend1=legend([l1 l2 l3],'Labor Income Tax','Capital Income Tax','Total Tax Liabilities/Output','Location','NorthEast');

if sav==1
saveas(gcf,'epsgraphs/Figure3_FH','eps');
end
