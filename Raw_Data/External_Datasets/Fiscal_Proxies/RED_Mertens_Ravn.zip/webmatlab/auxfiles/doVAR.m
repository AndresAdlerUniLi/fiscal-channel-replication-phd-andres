% This program computes the empirical VAR impulse responses
function RES = doVAR(VAR)

% Construct vectors of regressors and regressand: 
mL     = max(VAR.P,VAR.R);

x=[];
for i=0:VAR.P-1;    
   x(:,1+i:VAR.P:1+(VAR.nx-1)*VAR.P+i)=VAR.X(mL-i:VAR.T-i-1,:); 
end

TuL=zeros(VAR.T-mL,1+VAR.R); 
TaL=zeros(VAR.T-mL,1+VAR.R);
for i=0:VAR.R;
   TuL(:,1+i)=VAR.Tu(1+mL-i:VAR.T-i,1);
   TaL(:,1+i)=VAR.Ta(1+mL-i:VAR.T-i,1);
end

tre =(1:length(mL+1:VAR.T))'/100;
et = VAR.Ta(mL+1:VAR.T,2:VAR.K+1);
RX = [ones(length(mL+1:VAR.T),1) tre x TuL TaL et];
RY = VAR.X(mL+1:VAR.T,:);

% Get Estimates
beta= RX\RY;
b = beta([1 3:length(beta)],:);

% Get Impulse Responses to a 1% surprise tax cut 
nrx = length(b);
irs = zeros(1+VAR.irhor,VAR.nx);
xx  = zeros(VAR.irhor+2,nrx);
xx(1,1+VAR.nx*VAR.P+1)=-1;
for i = 1:VAR.irhor+1;
irs(i,:) = xx(i,:)*b;
xx(i+1,2:VAR.P:1+VAR.nx*VAR.P) = irs(i,:);
for j =1:VAR.nx;
xx(i+1,3+(j-1)*VAR.P:3+(j-1)*VAR.P+VAR.P-2)...
    = xx(i,2+(j-1)*VAR.P:2+(j-1)*VAR.P+VAR.P-2);
end
if i<VAR.R+1
xx(i+1,1+VAR.nx*VAR.P+1+i) = xx(1,1+VAR.nx*VAR.P+1);
end
end

RES.IRsup = irs;

% Get Impulse Responses to a 1% anticipated tax cut 
xx = zeros(VAR.irhor+VAR.K+2,nrx);
xx(1,1+VAR.nx*VAR.P+2*(VAR.R+1)+VAR.K)=-1;
ira = zeros(VAR.irhor+VAR.K+1,VAR.nx);
for i = 1:VAR.irhor+VAR.K+1;
ira(i,:) = xx(i,:)*b;
xx(i+1,2:VAR.P:1+VAR.nx*VAR.P) = ira(i,:);
for j =1:VAR.nx;
xx(i+1,3+(j-1)*VAR.P:3+(j-1)*VAR.P+VAR.P-2)...
    = xx(i,2+(j-1)*VAR.P:2+(j-1)*VAR.P+VAR.P-2);
end
if i<VAR.K
xx(i+1,1+VAR.nx*VAR.P+2*(VAR.R+1)+VAR.K-i) = xx(1,1+VAR.nx*VAR.P+2*(VAR.R+1)+VAR.K);
end
if i >=VAR.K && i<VAR.K+VAR.R+1
xx(i+1,1+VAR.nx*VAR.P+VAR.R+2+i-VAR.K) = xx(1,1+VAR.nx*VAR.P+2*(VAR.R+1)+VAR.K);    
end
end

RES.IRant = ira;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Bootstrapped confidence intervals:
if VAR.boot==1
    resid = RY - RX*beta;
    IRsupboot = zeros(length(RES.IRsup)*VAR.nx,VAR.nboot);
    IRantboot = zeros(length(RES.IRant)*VAR.nx,VAR.nboot);
    for nn = 1:VAR.nboot;
    yb     = zeros(VAR.T-mL,VAR.nx);
    
    
    % Draw Residuals 
    residb = zeros(VAR.T-mL,VAR.nx);
        for j = 1:VAR.nx;
    residb(:,j) = resid(randsample(VAR.T-mL,VAR.T-mL,true),j);
    residb(:,j) = residb(:,j)-mean(residb(:,j));
        end
    % Construct new series 
    RXb    = RX;
    xb     = zeros(VAR.T-mL,length(3:2+VAR.nx*VAR.P));
    xb(1,:)  = RX(1,3:2+VAR.nx*VAR.P);
    yb(1,:)  = RX(1,:)*beta+residb(1,:);
    
    for i = 2:VAR.T-mL
    xb(i,1:VAR.P:VAR.nx*VAR.P)  = yb(i-1,:);
    for j =1:VAR.nx;
    xb(i,2+(j-1)*VAR.P:2+(j-1)*VAR.P+VAR.P-2)...
    = xb(i-1,1+(j-1)*VAR.P:1+(j-1)*VAR.P+VAR.P-2);
    end
    RXb(i,3:2+length(xb(i,:)))=xb(i,:);
    yb(i,:) = RXb(i,:)*beta+residb(i,:);
    end
     
    
     
%Run VAR and compute IRS
betab =  [ones(length(mL+1:VAR.T),1) tre xb TuL TaL et]\yb;
bb = betab([1 3:length(betab)],:);
    % Get Impulse Responses to a 1% surprise tax cut 
xxb = zeros(VAR.irhor+2,nrx);
xxb(1,1+VAR.nx*VAR.P+1)=-1;
irsb = zeros(VAR.irhor+1,VAR.nx);
for i = 1:VAR.irhor+1;
irsb(i,:) = xxb(i,:)*bb;
xxb(i+1,2:VAR.P:1+VAR.nx*VAR.P) = irsb(i,:);
for j =1:VAR.nx;
xxb(i+1,3+(j-1)*VAR.P:3+(j-1)*VAR.P+VAR.P-2)...
    = xxb(i,2+(j-1)*VAR.P:2+(j-1)*VAR.P+VAR.P-2);
end
if i<VAR.R+1
xxb(i+1,1+VAR.nx*VAR.P+1+i) = xxb(1,1+VAR.nx*VAR.P+1);
end
end

IRsupboot(:,nn) = irsb(:);

% Get Impulse Responses to a 1% anticipated tax cut 
xxb = zeros(VAR.irhor+VAR.K+2,nrx);
irab = zeros(VAR.irhor+VAR.K+1,VAR.nx);
xxb(1,1+VAR.nx*VAR.P+2*(VAR.R+1)+VAR.K)=-1;
for i = 1:VAR.irhor+VAR.K+1;
irab(i,:) = xxb(i,:)*bb;
xxb(i+1,2:VAR.P:1+VAR.nx*VAR.P) = irab(i,:);
for j =1:VAR.nx;
xxb(i+1,3+(j-1)*VAR.P:3+(j-1)*VAR.P+VAR.P-2)...
    = xxb(i,2+(j-1)*VAR.P:2+(j-1)*VAR.P+VAR.P-2);
end
if i<VAR.K
xxb(i+1,1+VAR.nx*VAR.P+2*(VAR.R+1)+VAR.K-i) = xxb(1,1+VAR.nx*VAR.P+2*(VAR.R+1)+VAR.K);
end
if i >=VAR.K && i<VAR.K+VAR.R+1
xxb(i+1,1+VAR.nx*VAR.P+VAR.R+2+i-VAR.K) = xxb(1,1+VAR.nx*VAR.P+2*(VAR.R+1)+VAR.K);    
end
end
IRantboot(:,nn) = irab(:);
    end

RES.IRsupcih=reshape(prctile(IRsupboot',(100-VAR.clevel)/2)',length(RES.IRsup),VAR.nx);
RES.IRsupcil=reshape(prctile(IRsupboot',100-(100-VAR.clevel)/2)',length(RES.IRsup),VAR.nx);
RES.IRantcih=reshape(prctile(IRantboot',(100-VAR.clevel)/2)',length(RES.IRant),VAR.nx);
RES.IRantcil=reshape(prctile(IRantboot',100-(100-VAR.clevel)/2)',length(RES.IRant),VAR.nx);
RES.IRsupvar = reshape(var(IRsupboot')',length(RES.IRsup),VAR.nx);
RES.IRantvar = reshape(var(IRantboot')',length(RES.IRant),VAR.nx);
RES.IRcov = cov([IRsupboot' IRantboot'],1);
end
