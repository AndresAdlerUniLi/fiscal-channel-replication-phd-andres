function SE = doStandardErrors(x,PARS,EST,VAR,SHOCKS);

d= 6.0554544523933429e-6;

j=1;
if EST.select(1)==1; PARS.sigma  = 1/x(j); j=j+1; end
if EST.select(2)==1; PARS.kappa  = abs(x(j)); j=j+1; end
if EST.select(3)==1; PARS.mu     = x(j)^2/(1+x(j)^2); j=j+1; end
if EST.select(4)==1; PARS.phik   = abs(x(j)); j=j+1; end
if EST.select(5)==1; PARS.phiv   = abs(x(j)); j=j+1; end
if EST.select(6)==1; PARS.psik   = abs(x(j)); j=j+1; end
if EST.select(7)==1; PARS.lamk1  = min(x(j)^2/(1+x(j)^2),0.999); j=j+1; end
if EST.select(8)==1; PARS.lamk2  = min(x(j)^2/(1+x(j)^2),0.999); j=j+1; end
if EST.select(9)==1; PARS.lamn1  = min(x(j)^2/(1+x(j)^2),0.999); j=j+1; end
if EST.select(10)==1; PARS.lamn2 = min(x(j)^2/(1+x(j)^2),0.999); end
   
       PARS.rhok1 = PARS.lamk1+PARS.lamk2; PARS.rhok2 = -PARS.lamk1*PARS.lamk2;
       PARS.rhon1 = PARS.lamn1+PARS.lamn2; PARS.rhon2 = -PARS.lamn1*PARS.lamn2;

SOL = doMODEL(PARS);

simT      = length(SHOCKS.Tu)/EST.nsim;                       
Xsim  = doSIM(SOL,PARS,SHOCKS);
Xsim = Xsim+SHOCKS.me/100000;
Xsim = permute(reshape(Xsim,[simT EST.nsim 5]),[1 3 2]);
TR=repmat((1:VAR.T)'*log(PARS.gammaz),[1 VAR.nx]);
TR(:,4) = 0;
simTu = reshape(SHOCKS.Tu,[simT,EST.nsim]);
simTa = permute(reshape(SHOCKS.Ta(:,1:1+VAR.K),[simT EST.nsim 1+VAR.K]),[1 3 2]);

Vsimj      = VAR;    
Vsimj.boot = 1;
Vsimj.nboot = 100;

for j = 1:EST.nsim
Vsimj.X  = Xsim(:,:,j)+TR;
Vsimj.Tu = simTu(:,j);
Vsimj.Ta = simTa(:,:,j);
RESsim   = doVAR(Vsimj);
Sigmab(:,j) = RESsim.IRcov(:);
end

S = EST.nsim;
[S1,S2] = size(EST.Sigma);
Sigmasim = reshape(sum(Sigmab')/S^2,S1,S2);

j=1;
EST0 = EST;
EST0.select = zeros(length(EST.select));
if EST.select(1)==1; 
    PARS1 = PARS; PARS2=PARS;
    PARS1.sigma  = PARS.sigma+max(d,d*PARS.sigma);
    PARS2.sigma  = PARS.sigma-max(d,d*PARS.sigma);
    [OBJ1,ERES1]=lossfunction(0,PARS1,EST0,VAR,SHOCKS); Lambda1 =[ERES1.IRSUPsim(:);ERES1.IRANTsim(:)];
    [OBJ2,ERES2]=lossfunction(0,PARS2,EST0,VAR,SHOCKS); Lambda2 =[ERES2.IRSUPsim(:);ERES2.IRANTsim(:)];
    dPsi(:,j) = (Lambda1-Lambda2)/2/max(d,d*PARS.sigma);
    j=j+1; end
if EST.select(2)==1; 
    PARS1 = PARS; PARS2=PARS;
    PARS1.kappa  = PARS.kappa+max(d,d*PARS.kappa);
    PARS2.kappa  = PARS.kappa-max(d,d*PARS.kappa);
    [OBJ1,ERES1]=lossfunction(0,PARS1,EST0,VAR,SHOCKS); Lambda1 =[ERES1.IRSUPsim(:);ERES1.IRANTsim(:)];
    [OBJ2,ERES2]=lossfunction(0,PARS2,EST0,VAR,SHOCKS); Lambda2 =[ERES2.IRSUPsim(:);ERES2.IRANTsim(:)];
    dPsi(:,j) = (Lambda1-Lambda2)/2/max(d,d*PARS.kappa);
    j=j+1; end
if EST.select(3)==1; 
    PARS1 = PARS; PARS2=PARS;
    PARS1.mu = PARS.mu+max(d,d*PARS.mu);
    PARS2.mu  = PARS.mu-max(d,d*PARS.mu);
    [OBJ1,ERES1]=lossfunction(0,PARS1,EST0,VAR,SHOCKS); Lambda1 =[ERES1.IRSUPsim(:);ERES1.IRANTsim(:)];
    [OBJ2,ERES2]=lossfunction(0,PARS2,EST0,VAR,SHOCKS); Lambda2 =[ERES2.IRSUPsim(:);ERES2.IRANTsim(:)];
    dPsi(:,j) = (Lambda1-Lambda2)/2/max(d,d*PARS.mu);
    j=j+1; end
if EST.select(4)==1; 
    PARS1 = PARS; PARS2=PARS;
    PARS1.phik  = PARS.phik+max(d,d*PARS.phik);
    PARS2.phik  = PARS.phik-max(d,d*PARS.phik);
    [OBJ1,ERES1]=lossfunction(0,PARS1,EST0,VAR,SHOCKS); Lambda1 =[ERES1.IRSUPsim(:);ERES1.IRANTsim(:)];
    [OBJ2,ERES2]=lossfunction(0,PARS2,EST0,VAR,SHOCKS); Lambda2 =[ERES2.IRSUPsim(:);ERES2.IRANTsim(:)];
    dPsi(:,j) = (Lambda1-Lambda2)/2/max(d,d*PARS.phik);
    j=j+1; end
if EST.select(5)==1; 
    PARS1 = PARS; PARS2=PARS;
    PARS1.phiv  = PARS.phiv+max(d,d*PARS.phiv);
    PARS2.phiv  = PARS.phiv-max(d,d*PARS.phiv);
    [OBJ1,ERES1]=lossfunction(0,PARS1,EST0,VAR,SHOCKS); Lambda1 =[ERES1.IRSUPsim(:);ERES1.IRANTsim(:)];
    [OBJ2,ERES2]=lossfunction(0,PARS2,EST0,VAR,SHOCKS); Lambda2 =[ERES2.IRSUPsim(:);ERES2.IRANTsim(:)];
    dPsi(:,j) = (Lambda1-Lambda2)/2/max(d,d*PARS.phiv);
    j=j+1; end
if EST.select(6)==1; 
    PARS1 = PARS; PARS2=PARS;
    PARS1.psik  = PARS.psik+max(d,d*PARS.psik);
    PARS2.psik  = PARS.psik-max(d,d*PARS.psik);
    [OBJ1,ERES1]=lossfunction(0,PARS1,EST0,VAR,SHOCKS); Lambda1 =[ERES1.IRSUPsim(:);ERES1.IRANTsim(:)];
    [OBJ2,ERES2]=lossfunction(0,PARS2,EST0,VAR,SHOCKS); Lambda2 =[ERES2.IRSUPsim(:);ERES2.IRANTsim(:)];
    dPsi(:,j) = (Lambda1-Lambda2)/2/max(d,d*PARS.psik);
    j=j+1; end
if EST.select(7)==1; 
    PARS1 = PARS; PARS2=PARS;
    PARS1.rhok1  = PARS.rhok1+max(d,d*PARS.rhok1);
    PARS2.rhok1  = PARS.rhok1-max(d,d*PARS.rhok1);
    [OBJ1,ERES1]=lossfunction(0,PARS1,EST0,VAR,SHOCKS); Lambda1 =[ERES1.IRSUPsim(:);ERES1.IRANTsim(:)];
    [OBJ2,ERES2]=lossfunction(0,PARS2,EST0,VAR,SHOCKS); Lambda2 =[ERES2.IRSUPsim(:);ERES2.IRANTsim(:)];
    dPsi(:,j) = (Lambda1-Lambda2)/2/max(d,d*PARS.rhok1);
    j=j+1; end
if EST.select(8)==1; 
    PARS1 = PARS; PARS2=PARS;
    PARS1.rhok2  = PARS.rhok2+max(d,d*PARS.rhok2);
    PARS2.rhok2  = PARS.rhok2-max(d,d*PARS.rhok2);
    [OBJ1,ERES1]=lossfunction(0,PARS1,EST0,VAR,SHOCKS); Lambda1 =[ERES1.IRSUPsim(:);ERES1.IRANTsim(:)];
    [OBJ2,ERES2]=lossfunction(0,PARS2,EST0,VAR,SHOCKS); Lambda2 =[ERES2.IRSUPsim(:);ERES2.IRANTsim(:)];
    dPsi(:,j) = (Lambda1-Lambda2)/2/max(d,d*PARS.rhok2);
    j=j+1; end
if EST.select(9)==1; 
    PARS1 = PARS; PARS2=PARS;
    PARS1.rhon1  = PARS.rhon1+max(d,d*PARS.rhon1);
    PARS2.rhon1  = PARS.rhon1-max(d,d*PARS.rhon1);
    [OBJ1,ERES1]=lossfunction(0,PARS1,EST0,VAR,SHOCKS); Lambda1 =[ERES1.IRSUPsim(:);ERES1.IRANTsim(:)];
    [OBJ2,ERES2]=lossfunction(0,PARS2,EST0,VAR,SHOCKS); Lambda2 =[ERES2.IRSUPsim(:);ERES2.IRANTsim(:)];
    dPsi(:,j) = (Lambda1-Lambda2)/2/max(d,d*PARS.rhon1);
    j=j+1; end
if EST.select(10)==1; 
    PARS1 = PARS; PARS2=PARS;
    PARS1.rhon2  = PARS.rhon2+max(d,d*PARS.rhon2);
    PARS2.rhon2  = PARS.rhon2-max(d,d*PARS.rhon2);
    [OBJ1,ERES1]=lossfunction(0,PARS1,EST0,VAR,SHOCKS); Lambda1 =[ERES1.IRSUPsim(:);ERES1.IRANTsim(:)];
    [OBJ2,ERES2]=lossfunction(0,PARS2,EST0,VAR,SHOCKS); Lambda2 =[ERES2.IRSUPsim(:);ERES2.IRANTsim(:)];
    dPsi(:,j) = (Lambda1-Lambda2)/2/max(d,d*PARS.rhon2);
    j=j+1; end

V  = inv(dPsi'*EST.iSig*dPsi)*dPsi'*EST.iSig*[EST.Sigma+Sigmasim]*EST.iSig*dPsi*inv(dPsi'*EST.iSig*dPsi); 
SE = sqrt(diag(V))/sqrt(length(VAR.X));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function  Xsim = doSIM(SOL,PARS,SHOCKS);

simTT = length(SHOCKS.Tu);

ssim  = zeros(length(SOL.hx),simTT);
innov = zeros(length(SOL.hx),simTT);

innov(SOL.or.taun,:)  = SOL.Uscale*SHOCKS.Tu/PARS.taun;
innov(SOL.or.tauk,:)  = SOL.Uscale*SHOCKS.Tu/PARS.tauk;
for j=6
innov(SOL.or.tauklag+j,:) = SOL.Ascale(j)*SHOCKS.Tam(:,1)/PARS.tauk; 
innov(SOL.or.tauklag+16+j,:) = SOL.Ascale(j)*SHOCKS.Tam(:,1)/PARS.taun;
end

ssim(:,1) = innov(:,1);

for j =1:simTT-1
ssim(:,j+1) = SOL.hx*ssim(:,j)+innov(:,j+1);        
end

xsim = (SOL.gx*ssim)';

Xsim = log([SOL.SS.Y*exp(xsim(:,SOL.or.y)) SOL.SS.C*exp(xsim(:,SOL.or.c))...
        SOL.SS.I*exp(xsim(:,SOL.or.i)) SOL.SS.N*exp(xsim(:,SOL.or.n)) SOL.SS.D*exp(xsim(:,SOL.or.d))]);
