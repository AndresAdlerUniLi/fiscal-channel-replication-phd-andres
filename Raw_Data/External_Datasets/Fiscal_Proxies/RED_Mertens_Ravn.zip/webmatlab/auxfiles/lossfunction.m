function [OBJ,ERES,SOL]  = lossfunction(x,PARS,EST,VAR,SHOCKS,varargin)

j=1;
if EST.select(1)==1; PARS.sigma  = 1/x(j); j=j+1; end
if EST.select(2)==1; PARS.kappa  = abs(x(j)); j=j+1; end
if EST.select(3)==1; PARS.mu     = x(j)^2/(1+x(j)^2); j=j+1; end
if EST.select(4)==1; PARS.phik   = abs(x(j)); j=j+1; end
if EST.select(5)==1; PARS.phiv   = abs(x(j)); j=j+1; end
if EST.select(6)==1; PARS.psik   = abs(x(j)); j=j+1; end
if EST.select(7)==1; PARS.lamk1  = min(x(j)^2/(1+x(j)^2),0.999); j=j+1; end
if EST.select(8)==1; PARS.lamk2  = min(x(j)^2/(1+x(j)^2),0.999); j=j+1; end
if EST.select(9)==1; PARS.lamn1  = min(x(j)^2/(1+x(j)^2),0.999); j=j+1; end
if EST.select(10)==1; PARS.lamn2 = min(x(j)^2/(1+x(j)^2),0.999); end
   
        if EST.select(7)==1||EST.select(8)==1;
       PARS.rhok1 = PARS.lamk1+PARS.lamk2; PARS.rhok2 = -PARS.lamk1*PARS.lamk2;
        end
        if EST.select(9)==1||EST.select(10)==1;
       PARS.rhon1 = PARS.lamn1+PARS.lamn2; PARS.rhon2 = -PARS.lamn1*PARS.lamn2;
        end
        
if nargin==5
    warning off
[SOL] = doMODEL(PARS);
    warning on
    if SOL.invertibilityflag==1||SOL.stabilityflag==1||sum(imag(x)~=0)~=0
        OBJ = 10000;
        return;
    end
else
[SOL] = doMODEL(PARS,VAR.irhor);
end
simT  = length(SHOCKS.Tu)/EST.nsim;                       
Xsim  = doSIM(SOL,PARS,SHOCKS);
Xsim = Xsim+SHOCKS.me/100000;
Xsim = permute(reshape(Xsim,[simT EST.nsim 5]),[1 3 2]);
TR=repmat((1:VAR.T)'*log(PARS.gammaz),[1 VAR.nx]);
TR(:,4) = 0;
simTu = reshape(SHOCKS.Tu,[simT,EST.nsim]);
simTa = permute(reshape(SHOCKS.Ta(:,1:1+VAR.K),[simT EST.nsim 1+VAR.K]),[1 3 2]);

Vsimj      = VAR;    
Vsimj.boot = 0;
for j = 1:EST.nsim
Vsimj.X  = Xsim(:,:,j)+TR;
Vsimj.Tu = simTu(:,j);
Vsimj.Ta = simTa(:,:,j);
RESsim   = doVAR(Vsimj);
irs(:,j) = RESsim.IRsup(:);
ira(:,j) = RESsim.IRant(:);
end

ERES.IRSUPsim = reshape(mean(irs,2),length(RESsim.IRsup),VAR.nx)*100;
ERES.IRANTsim = reshape(mean(ira,2),length(RESsim.IRant),VAR.nx)*100;

Lambda =[ERES.IRSUPsim(:);ERES.IRANTsim(:)];

OBJ = [EST.Lambdahat-Lambda]'*EST.iSig*[EST.Lambdahat-Lambda];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function  Xsim = doSIM(SOL,PARS,SHOCKS);

simTT = length(SHOCKS.Tu);

ssim  = zeros(length(SOL.hx),simTT);
innov = zeros(length(SOL.hx),simTT);

innov(SOL.or.taun,:)  = SOL.Uscale*SHOCKS.Tu/PARS.taun;
innov(SOL.or.tauk,:)  = SOL.Uscale*SHOCKS.Tu/PARS.tauk;
for j=6
innov(SOL.or.tauklag+j,:) = SOL.Ascale(j)*SHOCKS.Tam(:,1)/PARS.tauk; 
innov(SOL.or.tauklag+16+j,:) = SOL.Ascale(j)*SHOCKS.Tam(:,1)/PARS.taun;
end

ssim(:,1) = innov(:,1);

for j =1:simTT-1
ssim(:,j+1) = SOL.hx*ssim(:,j)+innov(:,j+1);        
end

xsim = (SOL.gx*ssim)';

Xsim = log([SOL.SS.Y*exp(xsim(:,SOL.or.y)) SOL.SS.C*exp(xsim(:,SOL.or.c))...
        SOL.SS.I*exp(xsim(:,SOL.or.i)) SOL.SS.N*exp(xsim(:,SOL.or.n)) SOL.SS.D*exp(xsim(:,SOL.or.d))]);

