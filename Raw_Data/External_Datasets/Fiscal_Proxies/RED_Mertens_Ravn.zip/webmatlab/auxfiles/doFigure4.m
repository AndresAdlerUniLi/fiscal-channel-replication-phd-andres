 function h1 = doFigure4(xhat,PARS,EST,VAR,RES,SHOCKS,sav)

figno = 'epsgraphs/Fig4_FH';
 
[OBJ,ERES,SOL]  = lossfunction(xhat,PARS,EST,VAR,SHOCKS,1)

ERES.mIRSUP = SOL.irS;
ERES.mIRANT = SOL.irA;

vysup = [[zeros(VAR.K+1,1); ERES.mIRSUP(:,1)] ...
    [zeros(VAR.K+1,1); ERES.IRSUPsim(:,1)] ...
    [zeros(VAR.K+1,1); RES.IRsup(1:VAR.irhor+1,1)]];
veysup =[[zeros(VAR.K+1,1); RES.IRsupcih(:,1)]...
    [zeros(VAR.K+1,1); RES.IRsupcil(:,1)]];

vyant=[[0;ERES.mIRANT(:,1)] [0;ERES.IRANTsim(:,1)] [0;RES.IRant(1:1+VAR.K+VAR.irhor,1)]];
veyant =[[0;RES.IRantcih(:,1)] [0;RES.IRantcil(:,1)]];

LOWy = min(min([vysup veysup vyant veyant]));
UPy  = max(max([vysup veysup vyant veyant]));

vcsup=[[zeros(VAR.K+1,1); ERES.mIRSUP(:,2)]...
    [zeros(VAR.K+1,1); ERES.IRSUPsim(:,2)]...
    [zeros(VAR.K+1,1); RES.IRsup(1:VAR.irhor+1,2)]];
vecsup =[[zeros(VAR.K+1,1); RES.IRsupcih(:,2)]...
    [zeros(VAR.K+1,1); RES.IRsupcil(:,2)]];
vcant=[[0;ERES.mIRANT(:,2)] [0;ERES.IRANTsim(:,2)] [0;RES.IRant(1:1+VAR.K+VAR.irhor,2)]];
vecant =[[0;RES.IRantcih(:,2)] [0;RES.IRantcil(:,2)]];

LOWc = min(min([vcsup vecsup vcant vecant]));
UPc  = max(max([vcsup vecsup vcant vecant]));

visup=[[zeros(VAR.K+1,1); ERES.mIRSUP(:,3)]...
    [zeros(VAR.K+1,1); ERES.IRSUPsim(:,3)]...
    [zeros(VAR.K+1,1); RES.IRsup(1:VAR.irhor+1,3)]];
veisup =[[zeros(VAR.K+1,1); RES.IRsupcih(:,3)]...
    [zeros(VAR.K+1,1); RES.IRsupcil(:,3)]];
viant=[[0;ERES.mIRANT(:,3)] [0;ERES.IRANTsim(:,3)] [0;RES.IRant(1:1+VAR.K+VAR.irhor,3)]];
veiant =[[0;RES.IRantcih(:,3)] [0;RES.IRantcil(:,3)]];

LOWi = min(min([visup veisup viant veiant]));
UPi  = max(max([visup veisup viant veiant]));

vhsup=[[zeros(VAR.K+1,1); ERES.mIRSUP(:,4)]...
    [zeros(VAR.K+1,1); ERES.IRSUPsim(:,4)]...
    [zeros(VAR.K+1,1); RES.IRsup(1:VAR.irhor+1,4)]];
vehsup =[[zeros(VAR.K+1,1); RES.IRsupcih(:,4)]...
    [zeros(VAR.K+1,1); RES.IRsupcil(:,4)]];
vhant=[[0;ERES.mIRANT(:,4)] [0;ERES.IRANTsim(:,4)] [0;RES.IRant(1:1+VAR.K+VAR.irhor,4)]];
vehant =[[0;RES.IRantcih(:,4)] [0;RES.IRantcil(:,4)]];

LOWh = min(min([vhsup vehsup vhant vehant]));
UPh  = max(max([vhsup vehsup vhant vehant]));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
h1=figure;
subplot(2,2,1);
box on;
S=-VAR.K-1:VAR.irhor;
for i=VAR.K+2:length(S)-1
X=[S(i) S(i) S(i+1) S(i+1)];
Y=[veysup(i,1) veysup(i,2) veysup(i+1,2) veysup(i+1,1)];
if i==1
gg=patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
else patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
end
end
hold on
plot(-VAR.K-1:VAR.irhor,vysup(:,1),'ko-','MarkerSize',3);
hold on
plot(-VAR.K-1:VAR.irhor,vysup(:,2),'k--');
hold on
plot(-VAR.K-1:VAR.irhor,vysup(:,3),'k-');
hold on
plot(-VAR.K-1:VAR.irhor,zeros(VAR.K+1+VAR.irhor+1,1),'k');
hold off
set(gca,'XTick',[-5 0 5 10 15 20],'FontSize',5);
axis([-0.1 VAR.irhor+0.1 LOWy UPy ]);
xlabel('quarters','FontSize',8);
ylabel('percent','FontSize',8);
title('Output','FontWeight','bold','FontSize',8);

subplot(2,2,2);
box on;
S=-1-VAR.K:VAR.irhor;
for i=2:length(S)-1
X=[S(i) S(i) S(i+1) S(i+1)];
Y=[veyant(i,1) veyant(i,2) veyant(i+1,2) veyant(i+1,1)];
if i==1
gg=patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
else patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
end
end
hold on
plot(-1-VAR.K:VAR.irhor,vyant(:,1),'ko-','MarkerSize',3);
hold on
plot(-1-VAR.K:VAR.irhor,vyant(:,2),'k--');
hold on
plot(-1-VAR.K:VAR.irhor,vyant(:,3),'k-');
hold on
plot(-1-VAR.K:VAR.irhor,zeros(VAR.K+1+VAR.irhor+1,1),'k');
hold off
set(gca,'XTick',[-5 0 5 10 15 20],'FontSize',5);
axis([-0.1-VAR.K VAR.irhor+0.1 LOWy UPy ]);
xlabel('quarters','FontSize',8);
ylabel('percent','FontSize',8);
title('Output','FontWeight','bold','FontSize',8);
if sav == 1
saveas(gcf,strcat(figno,'_OUT'),'eps');
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
h2=figure;
subplot(2,2,1);
box on;
S=-VAR.K-1:VAR.irhor;
for i=VAR.K+2:length(S)-1
X=[S(i) S(i) S(i+1) S(i+1)];
Y=[vecsup(i,1) vecsup(i,2) vecsup(i+1,2) vecsup(i+1,1)];
if i==1
gg=patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
else patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
end
end
hold on
plot(-VAR.K-1:VAR.irhor,vcsup(:,1),'ko-','MarkerSize',3);
hold on
plot(-VAR.K-1:VAR.irhor,vcsup(:,2),'k--');
hold on
plot(-VAR.K-1:VAR.irhor,vcsup(:,3),'k-');
hold on
plot(-VAR.K-1:VAR.irhor,zeros(VAR.K+1+VAR.irhor+1,1),'k');
hold off
set(gca,'XTick',[-5 0 5 10 15 20],'FontSize',5);
axis([-0.1 VAR.irhor+0.1 LOWc UPc ]);
xlabel('quarters','FontSize',8);
ylabel('percent','FontSize',8);
title('Nondurables Consumption','FontWeight','bold','FontSize',8);

subplot(2,2,2);
box on;
S=-VAR.K-1:VAR.irhor;
for i=2:length(S)-1
X=[S(i) S(i) S(i+1) S(i+1)];
Y=[vecant(i,1) vecant(i,2) vecant(i+1,2) vecant(i+1,1)];
if i==1
gg=patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
else patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
end
end
hold on
plot(-VAR.K-1:VAR.irhor,vcant(:,1),'ko-','MarkerSize',3);
hold on 
plot(-VAR.K-1:VAR.irhor,vcant(:,2),'k--');
hold on
plot(-VAR.K-1:VAR.irhor,vcant(:,3),'k-');
hold on
plot(-VAR.K-1:VAR.irhor,zeros(VAR.K+1+VAR.irhor+1,1),'k');
hold off
set(gca,'XTick',[-5 0 5 10 15 20],'FontSize',5)
axis([-0.1-VAR.K VAR.irhor+0.1 LOWc UPc ])
xlabel('quarters','FontSize',8)
ylabel('percent','FontSize',8)
title('Nondurables Consumption','FontWeight','bold','FontSize',8)
if sav == 1
saveas(gcf,strcat(figno,'_CON'),'eps');
end
%%%%%%%%%%%%%%%%%%
h3 = figure;
subplot(2,2,1);
box on;
S=-VAR.K-1:VAR.irhor;
for i=VAR.K+2:length(S)-1
X=[S(i) S(i) S(i+1) S(i+1)];
Y=[veisup(i,1) veisup(i,2) veisup(i+1,2) veisup(i+1,1)];
if i==1
gg=patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
else patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
end
end
hold on
plot(-VAR.K-1:VAR.irhor,visup(:,1),'ko-','MarkerSize',3);
hold on
plot(-VAR.K-1:VAR.irhor,visup(:,2),'k--');
hold on
plot(-VAR.K-1:VAR.irhor,visup(:,3),'k-');
hold on
plot(-VAR.K-1:VAR.irhor,zeros(VAR.K+1+VAR.irhor+1,1),'k');
hold off
set(gca,'XTick',[-5 0 5 10 15 20],'FontSize',5);
axis([-0.1 VAR.irhor+0.1 LOWi UPi ]);
xlabel('quarters','FontSize',8);
ylabel('percent','FontSize',8);
title('Investment','FontWeight','bold','FontSize',8);

subplot(2,2,2);
box on;
S=-VAR.K-1:VAR.irhor;
for i=2:length(S)-1
X=[S(i) S(i) S(i+1) S(i+1)];
Y=[veiant(i,1) veiant(i,2) veiant(i+1,2) veiant(i+1,1)];
if i==1
gg=patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
else patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
end
end
hold on
plot(-VAR.K-1:VAR.irhor,viant(:,1),'ko-','MarkerSize',3);
hold on
plot(-VAR.K-1:VAR.irhor,viant(:,2),'k--');
hold on
plot(-VAR.K-1:VAR.irhor,viant(:,3),'k-');
hold on
plot(-VAR.K-1:VAR.irhor,zeros(VAR.K+1+VAR.irhor+1,1),'k');
hold off
set(gca,'XTick',[-5 0 5 10 15 20],'FontSize',5);
axis([-0.1-VAR.K VAR.irhor+0.1 LOWi UPi ]);
ylabel('percent','FontSize',8);
title('Investment','FontWeight','bold','FontSize',8);
if sav == 1
saveas(gcf,strcat(figno,'_INV'),'eps');
end
%%%%%%%%%%%%%%%%%%%%
h4 =figure;
subplot(2,2,1);
box on;
S=-VAR.K-1:VAR.irhor;
for i=VAR.K+2:length(S)-1
X=[S(i) S(i) S(i+1) S(i+1)];
Y=[vehsup(i,1) vehsup(i,2) vehsup(i+1,2) vehsup(i+1,1)];
if i==1
gg=patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
else patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
end
end
hold on
l1=plot(-VAR.K-1:VAR.irhor,vhsup(:,1),'ko-','MarkerSize',3);
hold on
l2=plot(-VAR.K-1:VAR.irhor,vhsup(:,2),'k--');
hold on
l3=plot(-VAR.K-1:VAR.irhor,vhsup(:,3),'k-');
plot(-VAR.K-1:VAR.irhor,zeros(VAR.K+1+VAR.irhor+1,1),'k');
xlabel('quarters','FontSize',8);
ylabel('percent','FontSize',8);
set(gca,'XTick',[-5 0 5 10 15 20],'FontSize',5);
axis([-0.1 VAR.irhor+0.1 LOWh UPh ]);
title('Hours','FontWeight','bold','FontSize',8);
legend1=legend([l1 l2 l3],'Model','Model-VAR','VAR','Location','SouthWest');

hold off

subplot(2,2,2);
box on;
S=-VAR.K-1:VAR.irhor;
for i=2:length(S)-1
X=[S(i) S(i) S(i+1) S(i+1)];
Y=[vehant(i,1) vehant(i,2) vehant(i+1,2) vehant(i+1,1)];
if i==1
gg=patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
else patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
end
end
hold on
l1=plot(-VAR.K-1:VAR.irhor,vhant(:,1),'ko-','MarkerSize',3);
hold on
l3=plot(-VAR.K-1:VAR.irhor,vhant(:,2),'k--');
hold on
l2=plot(-VAR.K-1:VAR.irhor,vhant(:,3),'k-');
hold on
plot(-VAR.K-1:VAR.irhor,zeros(VAR.K+1+VAR.irhor+1,1),'k');
hold off
set(gca,'XTick',[-5 0 5 10 15 20],'FontSize',5);
axis([-0.1-VAR.K VAR.irhor+0.1 LOWh UPh ]);
xlabel('quarters','FontSize',8);
ylabel('percent','FontSize',8);
title('Hours','FontWeight','bold','FontSize',8);
box on
if sav == 1
saveas(gcf,strcat(figno,'_HOURS'),'eps');
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

vdsup=[[zeros(VAR.K+1,1); ERES.mIRSUP(:,5)]...
    [zeros(VAR.K+1,1); ERES.IRSUPsim(:,5)]...
    [zeros(VAR.K+1,1); RES.IRsup(1:VAR.irhor+1,5)]];
vedsup =[[zeros(VAR.K+1,1); RES.IRsupcih(:,5)]...
    [zeros(VAR.K+1,1); RES.IRsupcil(:,5)]];
vdant=[[0;ERES.mIRANT(:,5)] [0;ERES.IRANTsim(:,5)] [0;RES.IRant(1:1+VAR.K+VAR.irhor,5)]];
vedant =[[0;RES.IRantcih(:,5)] [0;RES.IRantcil(:,5)]];

LOWd = min(min([vdsup vedsup vdant vedant]));
UPd  = max(max([vdsup vedsup vdant vedant]));
    
h5=figure;

subplot(2,2,1);
box on;
S=-1-VAR.K:VAR.irhor;
for i=VAR.K+2:length(S)-1
X=[S(i) S(i) S(i+1) S(i+1)];
Y=[vedsup(i,1) vedsup(i,2) vedsup(i+1,2) vedsup(i+1,1)];
if i==1
gg=patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
else patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
end
end
hold on
l1 =plot(-1-VAR.K:VAR.irhor,vdsup(:,1),'ko-','MarkerSize',3);
hold on
l3=plot(-VAR.K-1:VAR.irhor,vdsup(:,2),'k--');
hold on
l2=plot(-VAR.K-1:VAR.irhor,vdsup(:,3),'k-');
hold on
plot(-1-VAR.K:VAR.irhor,zeros(VAR.K+1+VAR.irhor+1,1),'k');
hold off
set(gca,'XTick',[-5 0 5 10 15 20],'FontSize',5);
axis([-0.1 VAR.irhor+0.1 LOWd UPd ]);
xlabel('quarters','FontSize',8);
ylabel('percent','FontSize',8);
title('Durables Purchases','FontWeight','bold','FontSize',8);

subplot(2,2,2);
box on;
S=-VAR.K-1:VAR.irhor;
for i=2:length(S)-1
X=[S(i) S(i) S(i+1) S(i+1)];
Y=[vedant(i,1) vedant(i,2) vedant(i+1,2) vedant(i+1,1)];
if i==1
gg=patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
else patch(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
end
end
hold on
plot(-VAR.K-1:VAR.irhor,vdant(:,1),'ko-','MarkerSize',3);
hold on 
l3=plot(-VAR.K-1:VAR.irhor,vdant(:,2),'k--');
hold on
l2=plot(-VAR.K-1:VAR.irhor,vdant(:,3),'k-');
hold on
plot(-VAR.K-1:VAR.irhor,zeros(VAR.K+1+VAR.irhor+1,1),'k');
hold off
set(gca,'XTick',[-5 0 5 10 15 20],'FontSize',5);
axis([-0.1-VAR.K VAR.irhor+0.1 LOWd UPd ]);
xlabel('quarters','FontSize',8);
ylabel('percent','FontSize',8);
title('Durables Purchases','FontWeight','bold','FontSize',8);
% legend1=legend([l2 l1],'Data','Model','Location','NorthEast');
% set(legend1,'Orientation','horizontal',...
%     'Position',[0.2676 0.005 0.5038 0.0462],'Fontsize',8);
if sav == 1
saveas(gcf,strcat(figno,'_DUR'),'eps');
end



