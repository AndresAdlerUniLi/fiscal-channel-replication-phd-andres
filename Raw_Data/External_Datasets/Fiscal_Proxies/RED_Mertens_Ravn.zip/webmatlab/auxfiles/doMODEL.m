function [SOL] = doMODEL(PARS,varargin);

% Steady State
%%%%%%%%%%%%%%
SS.Y = 1; SS.N = 0.25; CD = (1-0.119)/0.119; SS.G = 0.201;

SS.Gamma = PARS.betastar*PARS.deltat*PARS.tauk/(1-PARS.betastar*(1-PARS.deltat));
SS.K     = PARS.alfa*PARS.gammaz*PARS.betastar*(1-PARS.tauk)/(1-SS.Gamma)/(1-PARS.betastar*(1-PARS.delta));
SS.I     = (1-(1-PARS.delta)/PARS.gammaz)*SS.K;
SS.D     = (1-SS.I-SS.G)/(1+CD);
SS.V     = (1-(1-PARS.delta)/PARS.gammaz)^(-1)*SS.D;
SS.C     = CD*SS.D;
SS.Ktax  = (1-(1-PARS.deltat)/PARS.gammaz)^(-1)*SS.I;
SS.TRY   = (1-PARS.alfa)*PARS.taun+PARS.tauk*(PARS.alfa-PARS.deltat/PARS.gammaz*SS.Ktax);

XX       = SS.C/SS.V*PARS.betastar*PARS.gammaz/(1-PARS.betastar*(1-PARS.delta));
% Martin's formula:
% XX       = SS.C/SS.V*PARS.betastar/(1-PARS.betastar*(1-PARS.delta)/PARS.gammaz)
PARS.theta = XX/(1+XX);
PARS.Psik_prime = (1-PARS.tauk)*PARS.alfa*PARS.gammaz/SS.K/(1-SS.Gamma);

% Solve Model
%%%%%%%%%%%%%
  % state variables:
  or.k=1; or.v=2; or.ilag=3; or.dlag=4; or.clag=5; or.vlag=6; or.ktax=7; or.taun=8; or.tauk=9; or.taunlag=10; or.tauklag=11;
  % control variables:
  or.c=1; or.y=2; or.n=3; or.i=4; or.d=5; or.qk=6; or.qv=7; or.uk=8; or.lam=9; or.x=10; or.try=11; or.GAM=12;
  % preallocate coefficient matrices  
  nfx = zeros(or.tauklag+2*16+or.GAM,or.tauklag+2*16); nfxp = zeros(size(nfx)); 
  nfy = zeros(or.tauklag+2*16+or.GAM,or.GAM); nfyp = zeros(size(nfy));
  
  %MU of nondurable consumption
  eqn = 1;
  nfy(eqn,or.lam)= -1;
  nfx(eqn,or.v)  =  1-PARS.theta;
  nfy(eqn,or.c)  =-(1-PARS.theta);
  nfy(eqn,or.x)  = -PARS.sigma/(1-PARS.mu*PARS.betastar);
  nfyp(eqn,or.x) =  PARS.sigma*PARS.mu*PARS.betastar/(1-PARS.mu*PARS.betastar);
 
  %Consumption Basket
  eqn = eqn+1;
  nfy(eqn,or.x)  = -1;
  nfy(eqn,or.c)  = PARS.theta/(1-PARS.mu/PARS.gammaz);
  nfx(eqn,or.v)  = (1-PARS.theta)/(1-PARS.mu/PARS.gammaz);
  nfx(eqn,or.clag) = -PARS.mu/PARS.gammaz*PARS.theta/(1-PARS.mu/PARS.gammaz);
  nfx(eqn,or.vlag) = -PARS.mu/PARS.gammaz*(1-PARS.theta)/(1-PARS.mu/PARS.gammaz);

  %Labor Supply
  eqn = eqn+1; 
  nfy(eqn,or.n)   =-(PARS.kappa+1);
  nfy(eqn,or.lam) = 1;
  nfx(eqn,or.taun)= -PARS.taun/(1-PARS.taun);
  nfy(eqn,or.y)   = 1;
  
  %Capital Intertemporal Euler
  eqn = eqn+1;
  nfy(eqn,or.qk)    = -1;
  nfy(eqn,or.lam)   = -1;
  nfyp(eqn,or.lam)  =  1;
  nfxp(eqn,or.k)    =-(1-PARS.betastar*(1-PARS.delta));
  nfyp(eqn,or.y)    = (1-PARS.betastar*(1-PARS.delta));
  nfxp(eqn,or.tauk) =-(1-PARS.betastar*(1-PARS.delta))*PARS.tauk/(1-PARS.tauk);
  nfyp(eqn,or.qk)   =  PARS.betastar*(1-PARS.delta);
  nfyp(eqn,or.uk)   =- PARS.betastar*PARS.Psik_prime;
 
  %Durables Intertemporal Euler
  eqn = eqn+1;
  nfy(eqn,or.qv)    = -1;
  nfy(eqn,or.lam)   = -1;
  nfyp(eqn,or.lam)  =  1;
  nfxp(eqn,or.v)    =-(1-PARS.betastar*(1-PARS.delta));
  nfyp(eqn,or.c)    = (1-PARS.betastar*(1-PARS.delta));
  nfyp(eqn,or.qv)   =  PARS.betastar*(1-PARS.delta);
  
  %Investment
  eqn = eqn+1;
  nfy(eqn,or.qk)  = 1;
  nfy(eqn,or.GAM) = SS.Gamma/(1-SS.Gamma);
  nfy(eqn,or.i)   =-PARS.phik*PARS.gammaz^2*(1+PARS.betastar*PARS.gammaz);
  nfx(eqn,or.ilag)= PARS.phik*PARS.gammaz^2;
  nfyp(eqn,or.i)  = PARS.betastar*PARS.phik*PARS.gammaz^2*PARS.gammaz;

 %Durables Purchases
  eqn = eqn+1;
  nfy(eqn,or.qv)  = 1;
  nfy(eqn,or.d)   =-PARS.phiv*PARS.gammaz^2*(1+PARS.betastar*PARS.gammaz);
  nfx(eqn,or.dlag)= PARS.phiv*PARS.gammaz^2;
  nfyp(eqn,or.d)  = PARS.betastar*PARS.phiv*PARS.gammaz^2*PARS.gammaz;
  
 %Capital Utilization
  eqn = eqn+1;
  nfy(eqn,or.y)    = -1;
  nfx(eqn,or.k)    =  1;
  nfy(eqn,or.qk)   = 1;
  nfy(eqn,or.uk)   = 1+PARS.psik;
  nfx(eqn,or.tauk) = PARS.tauk/(1-PARS.tauk);

 %Law of Motion Capital
  eqn = eqn+1;
  nfxp(eqn,or.k) = -1;
  nfx(eqn,or.k) = (1-PARS.delta)/PARS.gammaz;
  nfy(eqn,or.i) = 1-(1-PARS.delta)/PARS.gammaz;
  nfy(eqn,or.uk) = -PARS.Psik_prime/PARS.gammaz;
  
 %Law of Motion Capital for Tax Purposes
  eqn = eqn+1;
  nfxp(eqn,or.ktax)= -1;
  nfx(eqn,or.ktax) = (1-PARS.deltat)/PARS.gammaz;
  nfy(eqn,or.i)    = SS.I/SS.Ktax;
  
 %Law of Motion Durables
  eqn = eqn+1;
  nfxp(eqn,or.v) = -1;
  nfx(eqn,or.v) = (1-PARS.delta)/PARS.gammaz;
  nfy(eqn,or.d) = 1-(1-PARS.delta)/PARS.gammaz;

 %Depreciation Allowances
  eqn = eqn+1;
  nfy(eqn,or.GAM) = -1;  
  nfy(eqn,or.lam) = -1;
  nfyp(eqn,or.lam)= 1;
  nfxp(eqn,or.tauk)= 1-PARS.betastar*(1-PARS.deltat);
  nfyp(eqn,or.GAM) = PARS.betastar*(1-PARS.deltat);
  
 %Production Function
  eqn = eqn+1;
  nfy(eqn,or.y) = -1;  
  nfy(eqn,or.uk) = PARS.alfa;
  nfx(eqn,or.k)  = PARS.alfa;
  nfy(eqn,or.n)  = (1-PARS.alfa);
  
  %Goods Market Clearing
  eqn = eqn+1;
  nfy(eqn,or.y) = -1;
  nfy(eqn,or.c) = SS.C;
  nfy(eqn,or.d) = SS.D;
  nfy(eqn,or.i) = SS.I;
  
  %Tax Liabilities
  eqn = eqn+1;
  nfy(eqn,or.try)  =-SS.TRY;
  nfx(eqn,or.taun) = (1-PARS.alfa)*PARS.taun;
  nfx(eqn,or.tauk) = PARS.tauk*(PARS.alfa-PARS.deltat*SS.Ktax/PARS.gammaz);
  nfy(eqn,or.y)    = PARS.tauk*PARS.deltat*SS.Ktax/PARS.gammaz;
  nfx(eqn,or.ktax) =-PARS.tauk*PARS.deltat*SS.Ktax/PARS.gammaz;
  
  % Lagged Variables
  eqn = eqn+1; 
  nfxp(eqn,or.ilag)= -1;
  nfy(eqn,or.i)  = 1;
  
  eqn = eqn+1; 
  nfxp(eqn,or.clag)= -1;
  nfy(eqn,or.c)  = 1;
  
  eqn = eqn+1; 
  nfxp(eqn,or.dlag)= -1;
  nfy(eqn,or.d)  = 1;

  eqn = eqn+1; 
  nfxp(eqn,or.vlag)= -1;
  nfx(eqn,or.v)  = 1;
  
  eqn = eqn+1; 
  nfxp(eqn,or.tauklag)= -1;
  nfx(eqn,or.tauk)  = 1;
  
  eqn = eqn+1; 
  nfxp(eqn,or.taunlag)= -1;
  nfx(eqn,or.taun)  = 1;
  
  % LOM Tax Rates
  eqn = eqn+1; taukeq = eqn;
  nfxp(eqn,or.tauk)    = -1;
  nfx(eqn,or.tauk)     = PARS.rhok1; 
  nfx(eqn,or.tauklag)  = PARS.rhok2;
  
  eqn = eqn+1; tauneq = eqn;
  nfxp(eqn,or.taun)    = -1;
  nfx(eqn,or.taun)     = PARS.rhon1; 
  nfx(eqn,or.taunlag)  = PARS.rhon2;
  
  % News Lag Structure
  nfx(taukeq,or.tauklag+1) = 1;
  nfx(tauneq,or.tauklag+16+1) = 1;
   
  for i=1:16-1
  eqn = eqn+1;
  nfxp(eqn,or.tauklag+i) = -1;
  nfx(eqn,or.tauklag+i+1) = 1;
  end

  eqn = eqn+1;
  nfxp(eqn,or.tauklag+16) = -1;
  
  for i=1:16-1
  eqn = eqn+1;
  nfxp(eqn,or.tauklag+16+i) = -1;
  nfx(eqn,or.tauklag+16+i+1) = 1;
  end
  
  eqn = eqn+1;
  nfxp(eqn,or.tauklag+2*16) = -1;


[SOL.gx,SOL.hx,SOL.invertibilityflag,SOL.stabilityflag]=solab([-nfxp -nfyp],[nfx nfy],size(nfx,2)); 

SOL.Uscale = log((SS.TRY+0.01)/SS.TRY)/(SOL.gx(or.try,or.tauk)/PARS.tauk+SOL.gx(or.try,or.taun)/PARS.taun);
for j=1:16;
GX    = SOL.gx*SOL.hx^j;
SOL.Ascale(j) = log((SS.TRY+0.01)/SS.TRY)/(GX(or.try,or.tauklag+j)/PARS.tauk+GX(or.try,or.tauklag+16+j)/PARS.taun);
end
SOL.or = or; SOL.or.taukA = or.tauklag+PARS.b; SOL.or.taunA = or.tauklag+16+PARS.b;
SOL.SS = SS;

if nargin==2;
irhor = varargin{1}(1);

% Compute Impulse Responses
  % 1) Unanticipated Tax Shock
       
  s = zeros(length(SOL.hx),1+irhor);
  s([or.tauk],1) = SOL.Uscale/PARS.tauk;
  s([or.taun],1) = SOL.Uscale/PARS.taun;
  
  for j = 1:irhor
  s(:,j+1) = SOL.hx*s(:,j);    
  end
  x = SOL.gx*s;
   
 SOL.irS = -[x(or.y,:)' x(or.c,:)' x(or.i,:)' x(or.n,:)' x(or.d,:)']*100;  
 SOL.irtaxU  = -[(SS.TRY*exp(x(or.try,:)')-SS.TRY) ]*100;
 SOL.irtauNU = -[(PARS.taun*exp(s([or.taun],:)')-PARS.taun)]*100;
 SOL.irtauKU = -[(PARS.tauk*exp(s([or.tauk ],:)')-PARS.tauk)]*100;
    
  % 2) Anticipated Tax Shock

  s = zeros(length(SOL.hx),1+PARS.b+irhor);
  s([or.tauklag+PARS.b],1) = SOL.Ascale(PARS.b)/PARS.tauk;
  s([or.tauklag+16+PARS.b],1) = SOL.Ascale(PARS.b)/PARS.taun;
  
  for j = 1:PARS.b+irhor
  s(:,j+1) = SOL.hx*s(:,j);    
  end
  x = SOL.gx*s;
  
 SOL.irA = -[x(or.y,:)' x(or.c,:)' x(or.i,:)' x(or.n,:)' x(or.d,:)']*100;
 SOL.irtaxA  = -[(SS.TRY*exp(x(or.try,:)')-SS.TRY) ]*100;
 SOL.irtauNA = -[(PARS.taun*exp(s([or.taun],:)')-PARS.taun)]*100;
 SOL.irtauKA = -[(PARS.tauk*exp(s([or.tauk ],:)')-PARS.tauk)]*100;
 
    end